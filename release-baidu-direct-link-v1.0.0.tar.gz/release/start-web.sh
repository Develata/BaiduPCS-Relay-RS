#!/bin/bash
set -e
PORT=${PORT:-5200}
echo "🚀 启动 Web 服务器..." 
echo "📝 访问地址: http://localhost:${PORT}"
./baidu-direct-link-web
